import express  from "express";
const app = express();
app.use(express.json())

const  vagas = [
    {id:1,"titulo": "dev back-end"},
    {id: 2, "titulo": "dev Mobile"}
]
app.get('/',(req, res)=> {
    res.status(200). send('inicio Empregaeu');

})
app.get('/vagas',(req, res) =>{
    res.status(200). json(vagas)
})
app.post ('/vagas',(req, res) =>{
    vagas.push(req.body);
    res.status(201).send('vaga cadastrada com sucesso!, parabéns você sera um aprendiz de escravo')
})

app.put('/vagas/:id', (req, res)=>{
    let index = buscavaga(req.params.id);
    vagas[index].titulo = req.body.titulo;
    res.json (vagas) ;

})






function buscavaga (id){
    return vagas.findIndex(vagas => vagas.id == id)
}
export default app //preciso exporta para que outro arquivo
